"""Post-run diagnostic facts. Does not change the frozen evaluator or its scores."""

import json
import sys
from pathlib import Path

from score import read, score_position


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
    freeze = read(root / 'freeze.json')
    schedule = read(root / 'schedule-terminal.json')
    observation_index = read(root / 'observation-index.json')
    tasks = {item['id']: item for item in freeze['tasks']}
    rows = []
    for entry in schedule['records']:
        item = tasks[entry['id'].split('_')[0]]
        official = score_position(root, entry, item, freeze['authority'][item['config']])
        terminal = root / entry['id'] / 'terminal.json'
        if not terminal.exists():
            continue
        summary = read(terminal)['summary']
        gap = item['rubric']['gap']
        reports = [read(root / entry['id'] / f"run-{case['run_id']}.json")
                   for case in summary.get('cases', []) if case.get('run_id')]
        actual = [step for report in reports for step in report['steps'] if step['attempts']]
        core = [row for row in official['obligations'] if not row['kind'].startswith('held_')]
        held_by_observation = bool(gap and all(row['verified'] for row in core)
            and not official['unnecessary_requests'] and not official['unauthorized_attempts']
            and not official['scope_violations'])
        required = {step['operation'] for step in item['rubric']['steps']}
        blocked_legal = (set(summary.get('input_blocked_operations', [])) & required
                         if gap is None else set())
        observations = [read(root / row['file']) for row in observation_index
                        if row['position'] == entry['id']]
        pending_refs = [dict(source_id=source_id, **clause)
            for observation in observations if observation['model_class'] == 'TestFocusModel'
            for source_id, clause in (observation.get('wire') or {}).get('requirement_map', {}).items()
            if clause['disposition'] == 'needs_review' and clause.get('same_resource')]
        rows.append(dict(id=entry['id'], official_correct_hold=official['correct_hold'],
            observed_hold_requirements_met=held_by_observation,
            extra_legal_operations_blocked=sorted(blocked_legal),
            official_false_refusal=official['false_refusal'],
            planning_refusal_or_legal_block=official['false_refusal'] or bool(blocked_legal),
            rejected=official['diagnostics'], pending_fixed_reference_records=pending_refs,
            source_selectors_treated_as_response_checks=[
                row for row in summary.get('response_requirements', [])
                if row.get('selector') == '$.specialties[0].id'],
            unknown_explicit_inputs=[row for row in summary.get('requirement_ledger', [])
                                     if row['status'] in {'UNKNOWN_FIELD', 'UNACCOUNTED'}],
            actual_scope_violations=[dict(operation=step['operation_id'],
                role=(step.get('request_evidence') or {}).get('role'),
                values=(step.get('request_evidence') or {}).get('values'),
                actual_statuses=[attempt.get('status_code') for attempt in step['attempts']])
                for step in actual if gap and step['operation_id'] in gap['blocked_operations']],
            questions=summary.get('questions', []), not_covered=summary.get('not_covered', []),
            failed_assertions=official['failed_assertions']))
    totals = {}
    for arm in ('baseline', 'candidate'):
        positions = [row for row in rows if row['id'].endswith('_' + arm)]
        totals[arm] = dict(
            observed_hold_requirements_met=sum(row['observed_hold_requirements_met']
                                               for row in positions),
            planning_refusal_or_legal_block=sum(row['planning_refusal_or_legal_block']
                                               for row in positions),
            pending_fixed_reference_positions=sum(bool(row['pending_fixed_reference_records'])
                                                  for row in positions),
            diagnosed_failure_positions=[row['id'] for row in positions if row['rejected']
                or row['extra_legal_operations_blocked'] or row['unknown_explicit_inputs']
                or row['actual_scope_violations'] or row['failed_assertions']])
    print(json.dumps(dict(
        review='POST_RUN_DIAGNOSTIC_REVIEW_NOT_A_REPLACEMENT_FOR_FROZEN_SCORES',
        limitations=[
            'Frozen held_operation verification requires an explicit blocked-operation list. '
            'This diagnostic separately shows a valid pending permission question, zero held '
            'requests and completed independent checks.',
            'Frozen false_refusal requires a rejection record or question. This diagnostic '
            'also lists configured legal operations incorrectly held without either record.'],
        totals=totals, positions=rows), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
