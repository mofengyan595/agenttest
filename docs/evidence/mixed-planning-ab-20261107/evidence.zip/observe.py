"""Identical evaluation-only decode observer; preserves return values and exceptions."""

import json
import os
import runpy
import sys
from pathlib import Path
from uuid import uuid4

from dotenv import dotenv_values


def scrub(value, secrets):
    if isinstance(value, dict):
        return {key: ('[REDACTED]' if any(word in key.lower() for word in
                ('password', 'authorization', 'cookie', 'api_key')) else scrub(item, secrets))
                for key, item in value.items()}
    if isinstance(value, list):
        return [scrub(item, secrets) for item in value]
    if isinstance(value, str):
        for secret in secrets:
            value = value.replace(secret, '[REDACTED_SECRET]')
    return value


def observed(original, folder, secrets):
    def decode(self, content, context):
        record = dict(model_class=type(self).__name__,
                      request_sha256=getattr(self.stats, 'request_sha256', None))
        try:
            data = json.loads(content)
            if isinstance(data, dict):
                record['wire'] = {key: data[key] for key in
                    ('interpretation', 'requirement_map', 'scope', 'blocked_operations',
                     'cases', 'questions', 'not_covered', 'selection', 'purpose') if key in data}
        except (ValueError, TypeError):
            record['wire'] = None
        try:
            result = original(self, content, context)
            record['decode'] = 'ACCEPTED'
            return result
        except Exception as error:
            record['decode'] = 'REJECTED'
            diagnostic = getattr(error, 'diagnostic', None)
            record['diagnostic'] = diagnostic.model_dump(mode='json') if diagnostic else None
            record['exception_type'] = type(error).__name__
            raise
        finally:
            folder.mkdir(exist_ok=True)
            with (folder / (uuid4().hex + '.json')).open('x', encoding='utf-8') as stream:
                json.dump(scrub(record, secrets), stream, ensure_ascii=False, indent=2)
                stream.write('\n')
    return decode


if __name__ == '__main__':
    source = Path(sys.argv.pop(1)).resolve()
    env_file = Path(sys.argv[sys.argv.index('--model-env') + 1])
    secrets = [value for key, value in dotenv_values(env_file).items() if value and len(value) >= 8
               and (key.endswith(('_KEY', '_TOKEN', '_PASSWORD', '_SECRET'))
                    or key.startswith('AGENTTEST_TARGET_'))]
    from agenttest.product_design import TestDesignModel
    from agenttest.product_focus import TestFocusModel
    from agenttest.product_probe import ProductProbeModel

    folder = Path(os.environ['AGENTTEST_EVAL_OBSERVATIONS'])
    for model in (TestFocusModel, TestDesignModel, ProductProbeModel):
        model._decode_output = observed(model._decode_output, folder, secrets)
    sys.argv[0] = str(source / 'scripts/serve_web_workspace.py')
    runpy.run_path(sys.argv[0], run_name='__main__')
