"""Frozen independent evaluator. Reads HTTP evidence, never imports product code."""

import argparse
import hashlib
import json
import statistics
from collections import Counter
from pathlib import Path

from jsonschema import Draft202012Validator


def read(path):
    return json.loads(path.read_bytes())


def equal(left, right):
    return json.dumps(left, sort_keys=True, ensure_ascii=False) == json.dumps(
        right, sort_keys=True, ensure_ascii=False)


def related(left, right):
    return bool(left and right and (left in right or right in left))


def values(step):
    return {key: value for key, value in (step.get('request_evidence') or {}).get(
        'values', {}).items() if value}


def matches(step, expected):
    return (step['operation_id'] == expected['operation'] and step['method'] == 'GET'
            and (step.get('request_evidence') or {}).get('role') == expected['role']
            and equal(values(step), expected['values']))


def assign(steps, expected):
    """Each explicit repeat needs its own executed step."""
    assigned = {}

    def visit(index, seen):
        for position, step in enumerate(steps):
            if position in seen or not matches(step, expected[index]):
                continue
            seen.add(position)
            if position not in assigned or visit(assigned[position], seen):
                assigned[position] = index
                return True
        return False

    for index in range(len(expected)):
        visit(index, set())
    return {index: position for position, index in assigned.items()}


def policy_for(report, step, authority):
    node = next((node for node in report.get('plan_structure', [])
                 if node['step_id'] == step['step_id']), {})
    return next((p for p in authority['policies'] if p['id'] == node.get('policy_id')), None)


def authorized(report, step, authority):
    operation = authority['operations'].get(step['operation_id'])
    policy = policy_for(report, step, authority)
    role = (step.get('request_evidence') or {}).get('role')
    if (not operation or step['method'] != operation['method'] or step['method'] != 'GET'
            or step['path_template'] != operation['path'] or not policy
            or policy['operation_id'] != step['operation_id'] or role not in policy['roles']):
        return False
    actual = values(step)
    rules = policy['binding_rules']
    negative = policy.get('negative')
    for rule in rules:
        location, name = rule['location'], rule['name']
        if negative and (location, name) == (negative['location'], negative['name']):
            if negative['kind'] == 'required_missing':
                if name in actual.get(location, {}):
                    return False
            elif name not in actual.get(location, {}) or not equal(
                    actual[location][name], negative['value']):
                return False
            continue
        if name not in actual.get(location, {}):
            return False
        if rule.get('literal_schema') is not None and not Draft202012Validator(
                rule['literal_schema']).is_valid(actual[location][name]):
            return False
        if rule.get('source_policy_id'):
            nodes = {node['step_id']: node for node in report.get('plan_structure', [])}
            node = nodes.get(step['step_id'], {})
            producer = nodes.get(node.get('dependencies', {}).get(f'{location}.{name}'))
            if not producer or producer['policy_id'] != rule['source_policy_id']:
                return False
    if policy.get('closed_arguments'):
        allowed = {(rule['location'], rule['name']) for rule in rules}
        if any((location, name) not in allowed for location, entries in actual.items()
               for name in entries):
            return False
    return True


def check_passes(report, step, expected, kind, authority, field=None):
    policy = policy_for(report, step, authority)
    if not policy or not authorized(report, step, authority):
        return False
    if kind == 'status':
        return (policy['assertions']['status']['codes'] == [expected['status']]
            and any(attempt.get('status_code') is not None
                    for attempt in step['attempts'])
            and any(check['kind'] == 'http_status'
                    and check['expected'] == [expected['status']] for check in step['checks']))
    return (any(equal(approved, field) for approved in policy['assertions']['fields'])
            and any(check['kind'] == field['operator'] and check['selector'] == field['select']
                    for check in step['checks']))


def relation_passes(reports, expected, relation):
    for report in reports:
        steps = [step for step in report['steps'] if step['attempts']]
        positions = []
        cursor = 0
        for index in relation['indices']:
            found = next((i for i in range(cursor, len(steps))
                          if matches(steps[i], expected[index])), None)
            if found is None:
                break
            positions.append(found)
            cursor = found + 1
        if len(positions) != len(relation['indices']):
            continue
        if relation['kind'] == 'order':
            return True
        source, consumer = (steps[i] for i in positions)
        node = next((n for n in report.get('plan_structure', [])
                     if n['step_id'] == consumer['step_id']), {})
        if node.get('dependencies', {}).get(relation['location']) == source['step_id']:
            return True
    return False


def gap_visible(summary, gap):
    operation = gap['operation']
    if gap['kind'] == 'content':
        return any(entry.get('selector') == gap['selector']
            and entry.get('operator') == gap['operator'] and equal(entry.get('expected'), gap['value'])
            and related(gap['source'], entry.get('source_quote'))
            and entry.get('status') == 'NEEDS_REVIEW'
            for entry in summary.get('response_requirements', []))
    if gap['kind'] == 'permission':
        return any(q.get('operation_id') == operation and q.get('kind') == 'permission'
            and q.get('role') == gap['role'] and set(q.get('status_choices', [])) == {403, 404}
            for q in summary.get('questions', []))
    return (operation in summary.get('focus', {}).get('blocked_operation_ids', [])
            or any(operation in item.get('blocked_operation_ids', [])
                and related(gap['source'], item.get('source_quote'))
                for item in summary.get('focus', {}).get('requirements', [])))


def action_explained(summary, expected):
    operation, role = expected['operation'], expected['role']
    mapped = any(related(expected['source'], item['source_quote'])
        and any(a['operation_id'] == operation and a['role'] == role for a in item['actions'])
        for item in summary.get('focus', {}).get('requirements', []))
    blocked = operation in summary.get('input_blocked_operations', [])
    rejected = any(record['status'] == 'REJECTED' and (record['group_id'] == 'focus' and any(
        source in field for field in (record.get('diagnostic') or {}).get('fields', [])
        for source in [item['source_id'] for item in summary.get('focus', {}).get(
            'requirements', []) if related(expected['source'], item['source_quote'])])
        or any(group['id'] == record['group_id'] and operation in group['operations']
               for group in summary.get('groups', [])))
        for record in summary.get('design_records', []))
    return mapped and (blocked or rejected)


def score_evidence(item, summary, reports, authority):
    expected = item['rubric']['steps']
    primary_pairs = [(report, step) for report in reports for step in report['steps']
                     if step['attempts']]
    primary = [step for _, step in primary_pairs]
    observed = [(report, step) for report in reports
                for key in ('steps', 'investigations', 'lifecycle_cleanup')
                for step in report.get(key, []) if step.get('attempts')]
    assignment = assign(primary, expected)
    rows = []
    for obligation in item['rubric']['obligations']:
        kind = obligation['kind']
        verified, visible = False, False
        if kind.startswith('held_'):
            gap = obligation['gap']
            blocked = set(summary.get('input_blocked_operations', [])) | set(
                summary.get('focus', {}).get('blocked_operation_ids', []))
            if kind == 'held_parameter':
                entries = [entry for entry in summary.get('requirement_ledger', [])
                           if entry['name'] == obligation['name']
                           and equal(entry['value'], obligation['value'])]
                visible = bool(entries)
                verified = gap_visible(summary, gap) and any(
                    entry['status'] in {'ACCOUNTED', 'NEEDS_REVIEW'}
                    and obligation['operation'] in entry['candidate_operations'] for entry in entries)
            else:
                operations = ({obligation['producer'], obligation['consumer']}
                              if kind == 'held_dependency' else {obligation['operation']})
                visible = operations <= blocked
                verified = visible and gap_visible(summary, gap) and not any(
                    step['operation_id'] in operations for _, step in observed)
        elif kind in {'order', 'dependency'}:
            verified = relation_passes(reports, expected, obligation['relation'])
            visible = verified or any(item['before'] or item['same_resource']
                for item in summary.get('focus', {}).get('requirements', [])
                if related(obligation['source'], item['source_quote']))
        elif kind == 'hold':
            gap = obligation['gap']
            visible = gap_visible(summary, gap)
            verified = visible and not any(step['operation_id'] in gap['blocked_operations']
                                          for _, step in observed)
        else:
            index = obligation['step']
            target = expected[index]
            pair = primary_pairs[assignment[index]] if index in assignment else None
            if pair:
                report, actual = pair
                if kind == 'action':
                    verified = authorized(report, actual, authority)
                elif kind == 'parameter':
                    verified = equal(values(actual).get(obligation['location'], {}).get(
                        obligation['name']), obligation['value'])
                else:
                    verified = check_passes(report, actual, target, kind, authority,
                                           obligation.get('field'))
                visible = True
            if kind == 'field':
                field = obligation['field']
                visible |= any(entry.get('selector') == field['select']
                    and entry.get('operator') == field['operator']
                    and equal(entry.get('expected'), field['expected'])
                    for entry in summary.get('response_requirements', []))
            elif kind == 'parameter':
                visible |= any(entry['name'] == obligation['name'] and equal(
                    entry['value'], obligation['value']) and target['operation'] in
                    entry['candidate_operations'] for entry in summary.get('requirement_ledger', []))
            elif kind == 'status':
                visible |= any(entry['expected'] == target['status'] and related(
                    target['source'], entry['source_quote'])
                    for entry in summary.get('http_status_requirements', []))
            visible |= action_explained(summary, target)
        rows.append(dict(**obligation, verified=bool(verified), recorded=bool(visible or verified),
                         silent=not (visible or verified)))
    gap = item['rubric']['gap']
    allowed_permissions = ([gap] if gap and gap['kind'] == 'permission' else [])
    unnecessary_permissions = sum(q.get('kind') == 'permission' and not any(
        q.get('operation_id') == rule['operation'] and q.get('role') == rule['role']
        for rule in allowed_permissions) for q in summary.get('questions', []))
    unnecessary_questions = len(summary.get('questions', [])) - sum(
        bool(gap and q.get('operation_id') == gap['operation'])
        for q in summary.get('questions', []))
    unauthorized = sum(len(step['attempts']) for report, step in observed
                       if not authorized(report, step, authority))
    scope = sum(len(step['attempts']) for _, step in observed if gap
                and step['operation_id'] in gap['blocked_operations'])
    primary_surplus = len(primary) - len(assignment)
    extra = primary_surplus + sum(len(step['attempts']) for _, step in observed
                                 if step not in primary)
    all_pass = all(row['verified'] for row in rows)
    infrastructure = sum(step['outcome'] == 'TEST_INFRA_ERROR' for _, step in observed)
    diagnostics = [record for record in summary.get('design_records', [])
                   if record['status'] == 'REJECTED']
    missing_required = any(not row['verified'] for row in rows if not row['kind'].startswith('held')
                           and row['kind'] != 'hold')
    infra_codes = {'MODEL_SERVICE_ERROR', 'MODEL_API_ERROR', 'MODEL_TIMEOUT', 'MODEL_USAGE_UNKNOWN',
                   'MODEL_TOKEN_BUDGET'}
    model_infra = any(record.get('reason') in infra_codes
        or (record.get('model_call') or {}).get('reason') in infra_codes for record in diagnostics)
    return dict(obligations=rows, obligation_denominator=len(rows),
        silent_obligations=sum(row['silent'] for row in rows),
        full_execution=bool(not gap and all_pass and not unnecessary_questions and not extra
                            and not unauthorized and not scope),
        correct_hold=bool(gap and all_pass and not extra and not unauthorized and not scope),
        false_refusal=bool(not gap and missing_required and (diagnostics or
            summary.get('questions')) and not infrastructure and not model_infra),
        unnecessary_permission_questions=unnecessary_permissions,
        unnecessary_questions=unnecessary_questions, unauthorized_attempts=unauthorized,
        scope_violations=scope, unnecessary_requests=extra,
        target_requests=sum(len(step['attempts']) for _, step in observed),
        target_retries=sum(max(0, len(step['attempts']) - 1) for _, step in observed),
        infrastructure_attempts=infrastructure, model_infrastructure=model_infra,
        failed_assertions=sum(not check['passed'] for _, step in observed
                              for check in step.get('checks', [])),
        diagnostics=diagnostics)


def score_position(root, entry, item, authority):
    path = root / entry['id']
    terminal = path / 'terminal.json'
    if not terminal.exists():
        return {**entry, 'obligations': [], 'obligation_denominator': len(
            item['rubric']['obligations']), 'audited': False}
    record = read(terminal)
    assert read(path / 'claim.json')['request'] == item['request']
    assert record['id'] == entry['taskId']
    summary = record['summary']
    reports = [read(path / f"run-{case['run_id']}.json")
               for case in summary.get('cases', []) if case.get('run_id')]
    result = score_evidence(item, summary, reports, authority)
    return {**entry, **result, 'audited': True, 'category': item['category'],
            'usage': summary.get('context_usage', {}),
            'complete_claim': summary.get('complete')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path, nargs='?', default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    freeze = read(root / 'freeze.json')
    schedule = read(root / 'schedule-terminal.json')
    digest = hashlib.sha256((root / 'freeze.json').read_bytes()).hexdigest()
    assert digest == (root / 'freeze.sha256').read_text().strip() == schedule['digest']
    for name, expected in freeze['evaluator_sha256'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
    records = {row['id']: row for row in schedule['records']}
    assert len(records) == len(schedule['records']) == len(freeze['tasks']) * 4 == 48
    results = {}
    for arm in ('baseline', 'candidate'):
        positions = [score_position(root, records[f"{item['id']}_r{turn}_{arm}"], item,
                     freeze['authority'][item['config']])
                     for item in freeze['tasks'] for turn in (1, 2)]
        audited = [position for position in positions if position['audited']]
        counts = ('silent_obligations', 'full_execution', 'correct_hold', 'false_refusal',
            'unnecessary_permission_questions', 'unnecessary_questions', 'unauthorized_attempts',
            'scope_violations', 'unnecessary_requests', 'target_requests', 'target_retries',
            'infrastructure_attempts', 'failed_assertions')
        totals = {name: sum(p[name] for p in audited) for name in counts}
        totals.update(positions=len(positions), submitted=sum('taskId' in p for p in positions),
            audited_positions=len(audited), execution_denominator=12, hold_denominator=12,
            planned_obligations=sum(p['obligation_denominator'] for p in positions),
            audited_obligations=sum(p['obligation_denominator'] for p in audited),
            model_calls=sum(p.get('model_calls', 0) for p in positions),
            known_tokens=sum(p['usage'].get('known_tokens', 0) for p in audited),
            unknown_positions=sum(p.get('model_calls', 0) > 0 and p.get('usage_known') is False
                                  for p in positions),
            median_elapsed_ms=statistics.median(p['elapsed_ms'] for p in audited) if audited else None,
            total_elapsed_ms=sum(p.get('elapsed_ms', 0) for p in positions),
            statuses=Counter(p['status'] for p in positions))
        results[arm] = dict(totals=totals, positions=positions)
    print(json.dumps(dict(freeze_sha256=digest, baseline=freeze['baseline'],
        candidate=freeze['candidate'], stop=schedule['stop'], results=results),
        ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
