"""Evaluation-side checks, frozen before the first paid position."""

import json
from copy import deepcopy
from types import SimpleNamespace

import pytest
from observe import observed, scrub
from score import assign, score_evidence


def sample(repeat=1, actual_status=200):
    expected = dict(operation='read', role=None, status=200,
                    values=dict(query=dict(n=2)), fields=[], source='读取 n=2')
    steps = [dict(step_id=f's{i}', operation_id='read', method='GET', path_template='/read',
        request_evidence=dict(role=None, values=dict(query=dict(n=2))), outcome='PASS',
        attempts=[dict(status_code=actual_status)], checks=[dict(kind='http_status',
            selector=None, expected=[200], actual=actual_status, passed=actual_status == 200)])
        for i in range(repeat)]
    report = dict(steps=steps, plan_structure=[dict(step_id=f's{i}', operation_id='read',
        role=None, policy_id='allowed', dependencies={}) for i in range(repeat)])
    authority = dict(operations=dict(read=dict(method='GET', path='/read')), policies=[dict(
        id='allowed', operation_id='read', roles=[None], assertions=dict(status=dict(codes=[200]),
            fields=[]), binding_rules=[dict(location='query', name='n',
                literal_schema=dict(type='integer', enum=[2]))], closed_arguments=True)])
    item = dict(rubric=dict(steps=[expected] * repeat, gap=None, relation=None, obligations=[
        dict(id=f'{i}.{kind}', kind=kind, step=i, source='读取 n=2')
        for i in range(repeat) for kind in ('action', 'status')]))
    return item, report, authority


def test_model_complete_claim_is_not_execution_evidence():
    item, _, authority = sample()
    result = score_evidence(item, dict(complete=True), [], authority)
    assert not result['full_execution'] and result['silent_obligations'] == 2


def test_one_read_cannot_prove_two_explicit_reads():
    item, report, authority = sample(2)
    report['steps'].pop()
    assert len(assign(report['steps'], item['rubric']['steps'])) == 1
    assert not score_evidence(item, {}, [report], authority)['full_execution']


def test_assertion_failure_is_preserved_separately_from_check_completion():
    item, report, authority = sample(actual_status=500)
    result = score_evidence(item, {}, [report], authority)
    assert result['full_execution'] and result['failed_assertions'] == 1
    assert not result['false_refusal'] and result['unauthorized_attempts'] == 0


def test_wrong_value_is_not_authorized_or_counted_as_success():
    item, report, authority = sample()
    report['steps'][0]['request_evidence']['values']['query']['n'] = 3
    result = score_evidence(item, {}, [report], authority)
    assert not result['full_execution'] and result['unauthorized_attempts'] == 1


def test_wrong_identity_is_not_an_execution_witness():
    item, report, authority = sample()
    report['steps'][0]['request_evidence']['role'] = 'other'
    result = score_evidence(item, {}, [report], authority)
    assert not result['full_execution'] and result['unauthorized_attempts'] == 1


def test_a_visible_hold_requires_independent_execution():
    item, report, authority = sample()
    gap = dict(kind='content', operation='held', selector='$.name', operator='equals',
               value='unknown', source='等于 unknown', blocked_operations=['held'])
    item['rubric'].update(gap=gap)
    item['rubric']['obligations'].append(dict(id='gap', kind='hold', source='等于 unknown', gap=gap))
    summary = dict(response_requirements=[dict(selector='$.name', operator='equals',
        expected='unknown', source_quote='等于 unknown', status='NEEDS_REVIEW')])
    assert score_evidence(item, summary, [report], authority)['correct_hold']
    assert not score_evidence(item, summary, [], authority)['correct_hold']


def test_invented_permission_question_prevents_full_completion():
    item, report, authority = sample()
    summary = dict(questions=[dict(operation_id='read', kind='permission', role='other')])
    result = score_evidence(item, summary, [report], authority)
    assert result['unnecessary_permission_questions'] == 1 and not result['full_execution']


def test_extra_read_is_not_ignored():
    item, report, authority = sample()
    second = deepcopy(report['steps'][0])
    second['step_id'] = 'extra'
    report['steps'].append(second)
    report['plan_structure'].append(dict(step_id='extra', policy_id='allowed'))
    result = score_evidence(item, {}, [report], authority)
    assert not result['full_execution'] and result['unnecessary_requests'] == 1


def test_decode_observer_preserves_return_value_and_exception(tmp_path):
    model = SimpleNamespace(stats=SimpleNamespace(request_sha256='known'))
    answer = object()
    assert observed(lambda *_: answer, tmp_path, [])(model, '{}', {}) is answer

    def broken(*_):
        raise ValueError('unchanged')

    with pytest.raises(ValueError, match='unchanged'):
        observed(broken, tmp_path, [])(model, '{}', {})
    assert sorted(json.loads(p.read_text())['decode'] for p in tmp_path.glob('*.json')) == [
        'ACCEPTED', 'REJECTED']


def test_decode_observer_scrubs_credentials_without_changing_planning_output():
    assert scrub(dict(question='value secret-long-value', password='hidden'),
                 ['secret-long-value']) == dict(question='value [REDACTED_SECRET]',
                                                password='[REDACTED]')


def test_a_held_explicit_parameter_cannot_disappear_from_the_denominator():
    item, report, authority = sample()
    gap = dict(kind='content', operation='held', selector='$.name', operator='equals',
               value='unknown', source='等于 unknown', blocked_operations=['held'])
    item['rubric']['gap'] = gap
    item['rubric']['obligations'].append(dict(id='held.id', kind='held_parameter',
        source='id=3', operation='held', name='id', value=3, gap=gap))
    result = score_evidence(item, {}, [report], authority)
    assert result['obligation_denominator'] == 3 and result['silent_obligations'] == 1


def test_order_requires_the_complete_sequence_in_one_actual_run():
    from score import relation_passes

    item, report, _ = sample(2)
    relation = dict(kind='order', indices=[0, 1])
    assert relation_passes([report], item['rubric']['steps'], relation)
    first, second = deepcopy(report), deepcopy(report)
    first['steps'] = report['steps'][:1]
    second['steps'] = report['steps'][1:]
    assert not relation_passes([first, second], item['rubric']['steps'], relation)
