import hashlib
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

root = Path.cwd().resolve()
out = Path(__file__).resolve().parent
old = out.parent / 'requirement-witness-20261106'
jar = Path((out.parent / 'petclinic-readonly-20261014/source-path.txt').read_text()).resolve()
jar /= 'target/spring-petclinic-rest-4.0.2.jar'
exe = old / 'gitea.exe'
runtime = old / 'gitea-ad541aa2'
assert (runtime / 'data/gitea.db').is_file()
metadata = json.loads((old / 'gitea-release.json').read_text(encoding='utf-8-sig'))
with exe.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == metadata['digest'][7:]
with jar.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == (
        '27780435e5d67e68b17dfd0e8b1c7e9a4c7787516ee8c3d1c682591867d0523c')
ports = {'petclinic': 18886, 'gitea': 18887, 'baseline': 18961, 'candidate': 18962,
         'followup': 18565}
commands = [
    ('petclinic', [r'D:\Java\jdk-17\bin\java.exe', '-jar', str(jar),
        '--server.address=127.0.0.1', '--server.port=18886',
        '--spring.profiles.active=h2,spring-data-jpa',
        '--spring.datasource.url=jdbc:h2:mem:stability_20261106;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE',
        '--spring.datasource.username=sa', '--spring.datasource.password=',
        '--spring.h2.console.enabled=false', '--petclinic.security.enable=false'], root),
    ('gitea', [str(exe), '--work-path', str(runtime), '--config', str(runtime/'app.ini'), 'web'],
     runtime),
]
for arm in ('baseline', 'candidate', 'followup'):
    source = out / ('source-' + arm)
    commands.append((arm, [sys.executable, str(out / 'observe.py'), str(source),
        '--port', str(ports[arm]), '--data', str(out / (arm + '-workspace')),
        '--model-env', str(out / 'private/target.env')], source))
requested = set(sys.argv[1:])
assert requested and requested <= set(ports)
for label in requested:
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', ports[label]))
run_name = '-'.join(sorted(requested))
children = []
try:
    for label, command, source in commands:
        if label not in requested:
            continue
        with (out / (label + '.log')).open('ab') as log:
            process = subprocess.Popen(command, cwd=source, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW,
                env={**os.environ, 'PYTHONPATH': str(source / 'src'), 'PYTHONUTF8': '1',
                     'PYTHONDONTWRITEBYTECODE': '1',
                     'AGENTTEST_EVAL_OBSERVATIONS': str(out / (label + '-observations'))})
        children.append((label, process))
    print(json.dumps({label: process.pid for label, process in children}), flush=True)
    deadline = time.monotonic() + 3600
    while time.monotonic() < deadline and not (out / (run_name + '.stop')).exists():
        if any(process.poll() is not None for _, process in children):
            raise RuntimeError('Acceptance child exited; see private logs.')
        time.sleep(0.5)
finally:
    for _, process in reversed(children):
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=20)
    (out / (run_name + '-stopped.json')).write_text(json.dumps({
        label: process.poll() for label, process in children}), encoding='utf-8')
