"""Seal the frozen experiment, scan secrets, and cold-recompute every score."""

import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import zipfile
from pathlib import Path

from dotenv import dotenv_values

ROOT = Path.cwd().resolve()
OUT = Path(__file__).resolve().parent
DESTINATION = ROOT / 'docs/evidence/mixed-planning-ab-20261107'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def score(path):
    return subprocess.check_output([sys.executable, str(path / 'score.py'), str(path)],
        env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONDONTWRITEBYTECODE': '1'}).replace(b'\r\n', b'\n')


def secret_check(name, data, secrets, depth=0):
    assert not any(value in data for value in secrets), name
    if name.endswith('.zip') and depth < 4:
        import io

        with zipfile.ZipFile(io.BytesIO(data)) as bundle:
            for member in bundle.namelist():
                secret_check(name + '/' + member, bundle.read(member), secrets, depth + 1)
    elif name.endswith('.json') and not name.startswith(
            ('source-baseline.zip/', 'source-candidate.zip/')):
        assert not re.search(rb'(?i)"(?:authorization|set-cookie|cookie|api_key)"\s*:\s*"',
                             data), name


if __name__ == '__main__':
    freeze = read(OUT / 'freeze.json')
    schedule = read(OUT / 'schedule-terminal.json')
    manifest = read(OUT / 'source-manifest.json')
    for arm in ('baseline', 'candidate'):
        assert sha((OUT / f'source-{arm}.zip').read_bytes()) == freeze['source_archives'][arm]
        for name, digest in manifest[arm].items():
            assert sha((OUT / ('source-' + arm) / name).read_bytes()) == digest, (arm, name)
    runtime = [name for name, digest in manifest['candidate'].items()
               if name.startswith('src/') and manifest['baseline'].get(name) != digest]
    assert len(runtime) == 4
    assert all(sha((ROOT / name).read_bytes()) == manifest['candidate'][name] for name in runtime)
    keys = dotenv_values(OUT / 'private/target.env')
    secrets = [value.encode() for key, value in keys.items() if value and len(value) >= 8
               and (key.endswith(('_KEY', '_PASSWORD', '_TOKEN', '_SECRET'))
                    or key.startswith('AGENTTEST_TARGET_'))]
    names = ['freeze.json', 'freeze.sha256', 'source-manifest.json',
        'score.py', 'test_score.py', 'run.mjs', 'serve.py', 'observe.py',
        'prepare.py', 'schedule-claim.json', 'schedule-terminal.json', 'offline.log',
        'preflight-initial-failure.json', 'preflight-journal.jsonl']
    scope = dict(full_archives_preserved_locally=freeze['source_archives'],
        baseline_commit=freeze['baseline'],
        delivery='Exact changed runtime modules and patch; reconstruct on the baseline Git commit. '
                 'Full source archives and manifests are preserved locally.',
        runtime_members={})
    for arm in ('baseline', 'candidate'):
        members = {name: manifest[arm][name] for name in runtime}
        runtime_path = OUT / ('runtime-' + arm + '-code.zip')
        if not runtime_path.exists():
            with zipfile.ZipFile(runtime_path, 'x', zipfile.ZIP_DEFLATED) as bundle:
                for name, digest in members.items():
                    data = (OUT / ('source-' + arm) / name).read_bytes()
                    assert sha(data) == digest
                    secret_check(name, data, secrets)
                    bundle.writestr(name, data)
        scope['runtime_members'][arm] = members
        names.append(runtime_path.name)
    (OUT / 'source-scope.json').write_bytes(json.dumps(scope, indent=2).encode() + b'\n')
    names.append('source-scope.json')
    patch = subprocess.check_output(['git', 'diff', '--', *runtime])
    secret_check('candidate-runtime.patch', patch, secrets)
    (OUT / 'candidate-runtime.patch').write_bytes(patch)
    names.append('candidate-runtime.patch')
    paths = [OUT / name for name in names]
    observation_index = []
    for arm in ('baseline', 'candidate'):
        for path in sorted((OUT / (arm + '-observations')).glob('*.json')):
            written = path.stat().st_mtime_ns
            positions = []
            for entry in schedule['records']:
                if not entry['id'].endswith('_' + arm):
                    continue
                claim = OUT / entry['id'] / 'claim.json'
                receipt = OUT / (entry['id'] + '.json')
                if claim.exists() and claim.stat().st_mtime_ns <= written <= receipt.stat().st_mtime_ns:
                    positions.append(entry['id'])
            assert len(positions) == 1, (path.name, positions)
            observation_index.append(dict(file=path.relative_to(OUT).as_posix(),
                sha256=sha(path.read_bytes()), written_ns=written, position=positions[0]))
    assert len(observation_index) == sum(row.get('model_calls', 0) for row in schedule['records'])
    (OUT / 'observation-index.json').write_bytes(json.dumps(
        observation_index, ensure_ascii=False, indent=2).encode() + b'\n')
    paths.append(OUT / 'observation-index.json')
    review = subprocess.check_output([sys.executable, str(OUT / 'behavior_review.py'), str(OUT)],
        env={**os.environ, 'PYTHONUTF8': '1'}).replace(b'\r\n', b'\n')
    (OUT / 'behavior-review.json').write_bytes(review)
    paths.extend(OUT / name for name in ('behavior_review.py', 'behavior-review.json', 'publish.py',
                                         'fixed.log'))
    for entry in schedule['records']:
        paths.append(OUT / (entry['id'] + '.json'))
        paths.extend(sorted((OUT / entry['id']).glob('*.json')))
    for arm in ('baseline', 'candidate'):
        paths.extend(sorted((OUT / (arm + '-observations')).glob('*.json')))
    assert len(paths) == len(set(paths))
    raw = score(OUT)
    results = json.loads(raw)
    DESTINATION.mkdir(parents=True, exist_ok=True)
    assert not (DESTINATION / 'manifest.json').exists()
    members = {}
    mode = 'a' if (DESTINATION / 'evidence.zip').exists() else 'x'
    with zipfile.ZipFile(DESTINATION / 'evidence.zip', mode, zipfile.ZIP_DEFLATED) as bundle:
        existing = set(bundle.namelist())
        for path in paths:
            name = path.relative_to(OUT).as_posix()
            data = path.read_bytes()
            secret_check(name, data, secrets)
            if name in existing:
                assert bundle.read(name) == data
            else:
                bundle.writestr(name, data)
            members[name] = sha(data)
    cold = OUT / 'cold'
    cold.mkdir(exist_ok=False)
    with zipfile.ZipFile(DESTINATION / 'evidence.zip') as bundle:
        assert len(bundle.namelist()) == len(members) and set(bundle.namelist()) == set(members)
        for name in bundle.namelist():
            assert (cold / name).resolve().is_relative_to(cold.resolve())
            assert sha(bundle.read(name)) == members[name]
        bundle.extractall(cold)
    assert score(cold) == raw
    assert subprocess.check_output([sys.executable, str(cold / 'behavior_review.py'), str(cold)],
        env={**os.environ, 'PYTHONUTF8': '1'}).replace(b'\r\n', b'\n') == review
    (DESTINATION / 'results.json').write_bytes(raw)
    (DESTINATION / 'behavior-review.json').write_bytes(review)
    with (DESTINATION / 'positions.csv').open('x', encoding='utf-8-sig', newline='') as stream:
        columns = ['id', 'status', 'audited', 'full_execution', 'correct_hold', 'false_refusal',
            'silent_obligations', 'obligation_denominator', 'unnecessary_permission_questions',
            'unauthorized_attempts', 'scope_violations', 'unnecessary_requests', 'target_requests',
            'model_calls', 'known_tokens', 'usage_known', 'elapsed_ms', 'diagnostic_codes']
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        for arm in ('baseline', 'candidate'):
            for row in results['results'][arm]['positions']:
                record = {key: row.get(key) for key in columns}
                record['known_tokens'] = row.get('usage', {}).get('known_tokens')
                record['diagnostic_codes'] = '|'.join(
                    (d.get('diagnostic') or d.get('model_call', {}).get('diagnostic') or {}).get(
                        'code', d.get('reason', '')) for d in row.get('diagnostics', []))
                writer.writerow(record)
    final = dict(archive_sha256=sha((DESTINATION / 'evidence.zip').read_bytes()),
        results_sha256=sha(raw), positions_sha256=sha((DESTINATION / 'positions.csv').read_bytes()),
        member_count=len(members), members=members, baseline=freeze['baseline'],
        candidate=freeze['candidate'], freeze_sha256=results['freeze_sha256'])
    (DESTINATION / 'manifest.json').write_bytes(
        json.dumps(final, ensure_ascii=False, indent=2).encode() + b'\n')
    print('Cold-recomputed and verified', len(members), 'archive members.')
    for arm, result in results['results'].items():
        print(arm, json.dumps(result['totals'], ensure_ascii=False))
    print('stop', results['stop'])
