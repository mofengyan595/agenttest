"""Evaluation-only preparation. Never calls a model or changes product code."""

import ast
import hashlib
import json
import os
import shutil
import sqlite3
import stat
import subprocess
import sys
import zipfile
from copy import deepcopy
from importlib.metadata import distributions
from pathlib import Path

import httpx

from agenttest.contracts import load_openapi
from agenttest.generic_intake import GenericSetup, build_generic_project
from agenttest.goal_server import target_environment
from agenttest.llm_planner import ModelSettings
from agenttest.selectors import select

ROOT = Path.cwd().resolve()
OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'requirement-witness-20261106'
PRIOR = json.loads((OLD / 'freeze.json').read_bytes())
BASELINE = '00f570b77524bfd9d70dcbe165e82f1e6233ac5e'
CONFIGS, TASKS = {}, []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    path = OUT / name
    with path.open('xb') as stream:
        stream.write(json.dumps(data, ensure_ascii=False, indent=2).encode() + b'\n')


def config(name, *parts, ordered=False, linked=False):
    result = deepcopy(PRIOR['configs'][parts[0]])
    document = json.loads(result['document'])
    for key in parts[1:]:
        other = PRIOR['configs'][key]
        assert other['generic']['base_url'] == result['generic']['base_url']
        document['paths'].update(json.loads(other['document'])['paths'])
        result['generic']['operations'].extend(deepcopy(other['generic']['operations']))
        for role in other['generic']['roles']:
            if role not in result['generic']['roles']:
                result['generic']['roles'].append(role)
    if ordered:
        first, second = result['generic']['operations'][:2]
        second['after_operations'] = [first['operation_id']]
    if linked:
        first, second = result['generic']['operations'][:2]
        assert (first['operation_id'], second['operation_id']) == ('getVet', 'getSpecialty')
        second['arguments'] = [dict(location='path_parameters', name='specialtyId',
            source_operation='getVet', selector='$.specialties[0].id')]
        second['checks'] = [dict(select='$.id', operator='equals', expected=1),
                            dict(select='$.name', operator='equals', expected='radiology')]
    result.update(name='隔离读取项目 ' + name,
                  document=json.dumps(document, ensure_ascii=False))
    CONFIGS[name] = result


def step(key, source, fields=(), *, role=None, status=None, values=None, negative=False):
    operation, = PRIOR['configs'][key]['generic']['operations']
    fixed = {}
    for argument in operation['arguments']:
        fixed.setdefault(argument['location'], {})[argument['name']] = argument['value']
    return dict(operation=operation['operation_id'], role=role or operation.get('role'),
        status=status or operation['statuses'][0], values=values if values is not None else fixed,
        fields=[field for field in operation['checks'] if field['select'] in fields],
        source=source, negative=negative)


def task(name, request, project, steps, *, category, relation=None, gap=None):
    obligations = []
    for index, expected in enumerate(steps):
        for kind in ('action', 'status'):
            obligations.append(dict(id=f's{index + 1}.{kind}', kind=kind, step=index,
                                    source=expected['source']))
        for location, values in expected['values'].items():
            for field, value in values.items():
                obligations.append(dict(id=f's{index + 1}.{location}.{field}', kind='parameter',
                    step=index, location=location, name=field, value=value,
                    source=expected['source']))
        for field in expected['fields']:
            obligations.append(dict(id=f"s{index + 1}.field.{field['select']}", kind='field',
                step=index, field=field, source=expected['source']))
    if relation:
        obligations.append(dict(id='relation', kind=relation['kind'], source=relation['source'],
                                relation=relation))
    if gap:
        obligations.append(dict(id='gap', kind='hold', source=gap['source'], gap=gap))
    TASKS.append(dict(id=name, request=request, config=project, category=category,
                     rubric=dict(steps=steps, relation=relation, gap=gap, obligations=obligations)))


def define():
    config('g-owned-private-public', 'private', 'settings')
    task('B01', '以 archivist 获取 owner="archivist"、repo="sealed-register" 的私有仓库并验证 HTTP 200；'
         '换 reviewer 获取同一个仓库并验证 HTTP 404；同时读取 API 分页配置，验证 $.default_paging_num 等于 30。',
         'g-owned-private-public', [
             step('private', '以 archivist 获取'),
             step('private', '换 reviewer 获取', role='reviewer', status=404),
             step('settings', '读取 API 分页配置', ['$.default_paging_num'])],
         category='identity_and_anonymous')
    config('g-profile-public', 'self', 'version', 'settings')
    task('B02', '用 archivist 查看当前账号并核对 $.login 等于 "archivist"；'
         '匿名读取 Gitea 版本并确认 HTTP 200；另外查看分页配置中的 $.max_response_items 等于 50。',
         'g-profile-public', [step('self', '查看当前账号', ['$.login']),
             step('version', '匿名读取 Gitea 版本'),
             step('settings', '查看分页配置', ['$.max_response_items'])],
         category='known_identity_public')
    config('p-repeat-specialty-vet', 'specialty', 'vet', ordered=True)
    source = '重复读取三次 specialtyId=2'
    task('B03', '重复读取三次 specialtyId=2 的专科记录，每次核对 HTTP 200；'
         '三次结束之后才读取 vetId=2 的兽医，并验证 $.firstName 等于 "Helen"。',
         'p-repeat-specialty-vet', [step('specialty', source)] * 3 + [
             step('vet', '读取 vetId=2', ['$.firstName'])], category='strict_repeat_order',
         relation=dict(kind='order', indices=[0, 1, 2, 3], source='三次结束之后'))
    config('g-repeat-private', 'version', 'private', ordered=True)
    task('B04', '连续请求两次 Gitea 版本接口并核对 HTTP 200；完成两次之后，'
         '以 archivist 查看 owner="archivist"、repo="sealed-register"，验证 $.private 等于 true。',
         'g-repeat-private', [step('version', '连续请求两次 Gitea 版本接口')] * 2 + [
             step('private', '以 archivist 查看', ['$.private'])], category='repeat_identity_order',
         relation=dict(kind='order', indices=[0, 1, 2], source='完成两次之后'))
    config('p-linked', 'vet', 'specialty', linked=True)
    task('B05', '先获取 vetId=2 的兽医，确认 HTTP 200；再用这次响应的 $.specialties[0].id '
         '读取对应专科，核对 $.name 等于 "radiology"。',
         'p-linked', [step('vet', '获取 vetId=2'), dict(
             step('specialty', '读取对应专科'), values=dict(path_parameters=dict(specialtyId=1)),
             fields=[dict(select='$.name', operator='equals', expected='radiology')])],
         category='response_resource_dependency',
         relation=dict(kind='dependency', indices=[0, 1], location='path_parameters.specialtyId',
                       selector='$.specialties[0].id', source='再用这次响应'))
    config('p-approved-negative', 'page-specialty-negative')
    task('B06', '读取 page=0、size=2 的宠物分页并验证 $.content 数量为 2；'
         '再检查已经批准的 size=0 下界负例并核对 HTTP 400；'
         '独立获取 specialtyId=2 的专科并验证 $.id 等于 2。',
         'p-approved-negative', [step('page', '读取 page=0、size=2', ['$.content']),
             step('page', 'size=0 下界负例', status=400,
                  values=dict(query=dict(page=0, size=0)), negative=True),
             step('specialty', '独立获取 specialtyId=2', ['$.id'])],
         category='approved_boundary_and_normal')
    config('p-content-pet', 'specialty', 'pet')
    task('B07', '查 specialtyId=2 的专科，验证 $.name 等于 "cardiology"；'
         '另查 ownerId=1、petId=1 的宠物，核对 $.name 等于 "Leo"。',
         'p-content-pet', [step('pet', '另查 ownerId=1、petId=1', ['$.name'])],
         category='content_hold_fixed_resource',
         gap=dict(kind='content', operation='getSpecialty', source='等于 "cardiology"',
                  selector='$.name', operator='equals', value='cardiology',
                  blocked_operations=['getSpecialty']))
    config('p-content-page', 'vet', 'page')
    task('B08', '获取 vetId=2 的兽医并要求 $.firstName 等于 "Harriet"；'
         '另外读取宠物 page=0、size=2，验证 $.content 数量为 2。',
         'p-content-page', [step('page', '另外读取宠物 page=0、size=2', ['$.content'])],
         category='content_hold_same_clause',
         gap=dict(kind='content', operation='getVet', source='等于 "Harriet"',
                  selector='$.firstName', operator='equals', value='Harriet',
                  blocked_operations=['getVet']))
    config('g-content-identity', 'self', 'settings', 'version')
    task('B09', 'archivist 读取当前账号并核对 $.login 等于 "archivist"；'
         '查询 API 分页配置并要求 $.max_response_items 等于 52；'
         '同时匿名读取 Gitea 版本，核对 $.version 等于 "1.26.3"。',
         'g-content-identity', [step('self', 'archivist 读取当前账号', ['$.login']),
             step('version', '同时匿名读取 Gitea 版本', ['$.version'])],
         category='mixed_identity_content_hold',
         gap=dict(kind='content', operation='getGeneralAPISettings', source='等于 52',
                  selector='$.max_response_items', operator='equals', value=52,
                  blocked_operations=['getGeneralAPISettings']))
    config('p-disabled', 'vet', 'page', 'specialty')
    CONFIGS['p-disabled']['generic']['operations'][0]['enabled'] = False
    task('B10', '尝试读取 vetId=2 的兽医详情；独立读取 page=0、size=2 的宠物分页，'
         '核对 $.content 数量为 2；另查 specialtyId=2 并核对 $.name 等于 "surgery"。',
         'p-disabled', [step('page', '独立读取 page=0、size=2', ['$.content']),
             step('specialty', '另查 specialtyId=2', ['$.name'])],
         category='unapproved_operation',
         gap=dict(kind='operation', operation='getVet', source='尝试读取 vetId=2',
                  blocked_operations=['getVet']))
    config('p-dependent-hold', 'vet', 'specialty', 'pet', linked=True)
    task('B11', '读取 vetId=2 的兽医并验证 $.firstName 等于 "Mira"；'
         '随后用该响应的 $.specialties[0].id 读取专科；'
         '与这个流程无依赖地读取 ownerId=1、petId=1 的宠物，验证 $.ownerId 等于 1。',
         'p-dependent-hold', [step('pet', '读取 ownerId=1、petId=1', ['$.ownerId'])],
         category='dependent_content_hold',
         gap=dict(kind='content', operation='getVet', source='等于 "Mira"',
                  selector='$.firstName', operator='equals', value='Mira',
                  blocked_operations=['getVet', 'getSpecialty']))
    config('g-unknown-role', 'private', 'version', 'settings')
    task('B12', '请确认 reviewer 读取 Gitea 版本时应该返回 403 还是 404；'
         '独立查询 API 分页配置，核对 $.default_paging_num 等于 30。',
         'g-unknown-role', [step('settings', '独立查询 API 分页配置', ['$.default_paging_num'])],
         category='requested_unknown_permission',
         gap=dict(kind='permission', operation='getVersion', role='reviewer',
                  source='reviewer 读取 Gitea 版本', blocked_operations=['getVersion']))
    held_inputs = {'B07': ('specialtyId', 2), 'B08': ('vetId', 2),
                   'B10': ('vetId', 2), 'B11': ('vetId', 2)}
    for item in TASKS:
        gap = item['rubric']['gap']
        if not gap:
            continue
        if gap['kind'] != 'operation':
            for operation in gap['blocked_operations']:
                item['rubric']['obligations'].append(dict(id='held.' + operation,
                    kind='held_operation', operation=operation, source=gap['source'], gap=gap))
        if item['id'] in held_inputs:
            name, value = held_inputs[item['id']]
            item['rubric']['obligations'].append(dict(id='held.' + name, kind='held_parameter',
                name=name, value=value, operation=gap['operation'], source=f'{name}={value}',
                gap=gap))
        if item['id'] == 'B11':
            item['rubric']['obligations'].append(dict(id='held.dependency', kind='held_dependency',
                source='随后用该响应', gap=gap, producer='getVet', consumer='getSpecialty'))


def compile_projects(environ):
    projects = {}
    for name, config_value in CONFIGS.items():
        projects[name] = build_generic_project('ab_' + name, config_value['document'],
            load_openapi(config_value['document']),
            GenericSetup.model_validate(config_value['generic']), environ=environ)
        assert not projects[name].target.allow_mutations
        assert all(op.method == 'GET' for op in projects[name].contract.operations)
        assert set(projects[name].target.allowed_operations) == {
            op['operation_id'] for op in config_value['generic']['operations']
            if op.get('enabled', True)}
    return projects


def preflight(environ, projects):
    evidence = []
    with httpx.Client(trust_env=False, timeout=15) as client:
        for item in TASKS:
            cfg = CONFIGS[item['config']]
            project = projects[item['config']]
            for expected in item['rubric']['steps']:
                operation = next(op for op in project.contract.operations
                                 if op.operation_id == expected['operation'])
                role = project.target.roles.get(expected['role'])
                headers = ({'Authorization': 'Bearer ' + environ[role.bearer_env]}
                           if role and role.bearer_env else {})
                values = expected['values']
                response = client.get(cfg['generic']['base_url'] + operation.path.format(
                    **values.get('path_parameters', {})), params=values.get('query', {}),
                    headers=headers)
                with (OUT / 'preflight-journal.jsonl').open('a', encoding='utf-8') as journal:
                    journal.write(json.dumps(dict(task=item['id'], operation=expected['operation'],
                        role=expected['role'], values=values, status=response.status_code,
                        response_sha256=sha(response.content)), ensure_ascii=False) + '\n')
                if not expected['negative']:
                    assert response.status_code == expected['status'], (
                        item['id'], expected['operation'], response.status_code, expected['status'])
                for field in expected['fields']:
                    actual = select(response.json(), field['select'])
                    if field['operator'] == 'count':
                        actual = len(actual)
                    assert type(actual) is type(field['expected']) and actual == field['expected']
                if item['id'] == 'B05' and expected['operation'] == 'getVet':
                    assert select(response.json(), '$.specialties[0].id') == 1
                evidence.append(dict(task=item['id'], operation=expected['operation'],
                    role=expected['role'], values=values, status=response.status_code,
                    approved_expected_status=expected['status'],
                    assertion_matches=response.status_code == expected['status'],
                    response_sha256=sha(response.content)))
    return evidence


def usage_preflight():
    checked = []
    for previous in ('mixed-planning-20261106', 'mixed-planning-followup-20261106'):
        for arm in ('baseline', 'candidate'):
            db = OUT.parent / previous / (arm + '-workspace/tasks.sqlite3')
            with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as conn:
                states = conn.execute('SELECT state,count(*) FROM model_usage_journal '
                                      'GROUP BY state').fetchall()
                assert all(state == 'KNOWN' for state, _ in states), (previous, arm, states)
                checked.append(dict(workspace=f'{previous}/{arm}', states=states))
    return checked


def snapshots():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == BASELINE
    allowed = {'docs/progress.md', 'src/agenttest/product_focus.py',
        'src/agenttest/product_focus_wire.py', 'src/agenttest/product_sources.py',
        'src/agenttest/request_requirements.py'}
    changed = set(subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines())
    assert changed == allowed
    extras = {'docs/mixed-planning-gaps-20261107.md', 'tests/test_mixed_planning_gaps.py'}
    archive = OUT / 'source-baseline.zip'
    subprocess.run(['git', 'archive', '--format=zip', f'--output={archive}', BASELINE], check=True)
    baseline = OUT / 'source-baseline'
    with zipfile.ZipFile(archive) as z:
        z.extractall(baseline)
    candidate = OUT / 'source-candidate'
    shutil.copytree(baseline, candidate)
    for name in allowed | extras:
        shutil.copyfile(ROOT / name, candidate / name)
    for tree in (baseline, candidate):
        shutil.copytree(ROOT / 'web/dist', tree / 'web/dist')
    manifests, prompts = {}, {}
    for arm, tree in (('baseline', baseline), ('candidate', candidate)):
        paths = sorted(path for path in tree.rglob('*') if path.is_file())
        manifests[arm] = {p.relative_to(tree).as_posix(): sha(p.read_bytes()) for p in paths}
        prompts[arm] = {}
        for module in ('product_focus.py', 'product_design.py', 'llm_planner.py'):
            parsed = ast.parse((tree / 'src/agenttest' / module).read_text(encoding='utf-8'))
            for node in parsed.body:
                if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and 'PROMPT' in target.id:
                            prompts[arm][module + ':' + target.id] = sha(node.value.value.encode())
        if arm == 'candidate':
            with zipfile.ZipFile(OUT / 'source-candidate.zip', 'x', zipfile.ZIP_DEFLATED) as z:
                for path in paths:
                    z.write(path, path.relative_to(tree).as_posix())
        for path in paths:
            path.chmod(stat.S_IREAD)
    assert prompts['baseline'] == prompts['candidate']
    save('source-manifest.json', manifests)
    return manifests, prompts


if __name__ == '__main__':
    define()
    history = ''
    for folder in ('docs', 'examples', 'tests'):
        for path in (ROOT / folder).rglob('*'):
            if path.suffix in {'.json', '.md', '.py'} and path.is_file():
                history += path.read_text(encoding='utf-8', errors='ignore') + '\n'
    for path in (ROOT / 'docs/evidence').rglob('*.zip'):
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.endswith('freeze.json'):
                    history += z.read(name).decode('utf-8', errors='ignore')
    assert len(TASKS) == len({t['request'] for t in TASKS}) == 12
    assert not any(item['request'] in history for item in TASKS)
    assert sum(item['rubric']['gap'] is None for item in TASKS) == 6
    environ = target_environment(OLD / 'target.env')
    projects = compile_projects(environ)
    evidence = preflight(environ, projects)
    print('Preflight:', len(evidence), 'GETs;', sum(not e['assertion_matches'] for e in evidence),
          'preserved target assertion mismatches', flush=True)
    if '--preflight-only' in sys.argv:
        for project in projects.values():
            for policy in project.registry.definitions():
                if policy.negative:
                    print('Approved negative', policy.operation_id,
                          policy.negative.model_dump(), policy.assertions.status.codes)
        raise SystemExit(0)
    prior_usage = usage_preflight()
    private = OUT / 'private'
    private.mkdir()
    shutil.copyfile(OLD / 'target.env', private / 'target.env')
    (private / 'target.env').chmod(stat.S_IREAD)
    settings = ModelSettings.from_env_file(private / 'target.env')
    assert settings.model == 'ecnu-max'
    manifests, prompts = snapshots()
    authority = {}
    for key, project in projects.items():
        authority[key] = dict(
            operations={op.operation_id: dict(method=op.method, path=op.path)
                        for op in project.contract.operations},
            policies=[policy.model_dump(mode='json') for policy in project.registry.definitions()],
            budget=project.registration.budget.model_dump(mode='json'),
            max_requests=project.target.max_requests, max_steps=project.target.max_steps)
    data = dict(baseline=BASELINE,
        candidate='sha256:' + sha(json.dumps(manifests['candidate'], sort_keys=True).encode()),
        ports=dict(baseline=18961, candidate=18962), rounds=2, model=settings.model,
        model_parameters=settings.model_dump(mode='json', exclude={'api_key', 'base_url'}),
        endpoint_sha256=sha(settings.base_url.encode()), temperature=0,
        authorization=dict(source='2026-11-07 explicit operator request for this 48-position A/B',
            inherited='configured real-model calls authorized; no goal-wide ceiling',
            task_limits='unchanged registered project budgets; no position resubmission',
            unknown_usage='stop subsequent model calls; retain UNKNOWN and unstarted positions'),
        previous_usage=prior_usage, targets=PRIOR['targets'], configs=CONFIGS, tasks=TASKS,
        authority=authority, preflight=evidence, prompt_sha256=prompts,
        source_archives={arm: sha((OUT / f'source-{arm}.zip').read_bytes())
                         for arm in ('baseline', 'candidate')},
        dependencies=sorted((d.metadata['Name'], d.version) for d in distributions()),
        review='DEVELOPMENT_ONLY_NO_INDEPENDENT_HUMAN_REVIEW',
        evaluator_sha256={name: sha((OUT / name).read_bytes())
                          for name in ('score.py', 'test_score.py', 'run.mjs', 'serve.py',
                                       'observe.py')},
        scoring_protocol=dict(
            completion='all requested authorized requests and approved assertions evaluated, '
                'including preserved ASSERTION_FAILED; assertion pass counted separately',
            silent='no successful witness and no requirement-specific execution, hold or rejection '
                'record; generic whole-task rejection alone does not explain every requirement',
            unnecessary='primary requests exceeding distinct frozen steps, plus diagnostic requests '
                'outside those steps, recorded separately from policy violations',
            first_rate_denominator=24, eligible_execution_denominator=12, hold_denominator=12))
    save('freeze.json', data)
    (OUT / 'freeze.sha256').write_text(sha((OUT / 'freeze.json').read_bytes()) + '\n',
                                      encoding='ascii')
    for name in ('freeze.json', 'freeze.sha256', 'source-manifest.json',
                 'source-baseline.zip', 'source-candidate.zip',
                 'score.py', 'test_score.py', 'run.mjs', 'serve.py', 'observe.py', 'prepare.py'):
        (OUT / name).chmod(stat.S_IREAD)
    print('Frozen 12 fresh tasks, 48 positions:', sha((OUT / 'freeze.json').read_bytes()))
