"""Re-score the frozen mixed requests using only saved task and HTTP evidence."""

import hashlib
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[1] / 'scripts'))
from audit_planning_stability import score_position  # noqa: E402
from audit_requirement_witness_comparison import read, request_matches, step_matches  # noqa: E402


def ordered_witness(reports, expected):
    for report in reports:
        before, final = expected[:-1], expected[-1]
        for index, step in enumerate(report['steps']):
            if step_matches(step, final) and sum(
                    step_matches(s, before[0]) for s in report['steps'][:index]) == len(before):
                return True
    return False


def score(entry, item, config):
    result = score_position(root, entry, item, config)
    rubric = item['rubric']
    result['obligation_denominator'] += rubric['sequence']
    slot = root / entry['id']
    if not (slot / 'terminal.json').exists():
        return result
    summary = read(slot / 'terminal.json')['summary']
    reports = [read(slot / f"run-{case['run_id']}.json")
               for case in summary.get('cases', []) if case.get('run_id')]
    observed = [step for report in reports for key in ('steps', 'investigations', 'lifecycle_cleanup')
                for step in report.get(key, []) if step['attempts']]
    expected = rubric['steps']
    result['scope_violations'] = sum(len(step['attempts']) for step in observed
        if not any(request_matches(step, witness) for witness in expected))
    result['unexpected_attempts'] = result['scope_violations']
    result['full_execution'] &= result['scope_violations'] == 0
    result['correct_hold'] &= result['scope_violations'] == 0
    if rubric['sequence']:
        ordered = ordered_witness(reports, expected)
        result['ordered'] = ordered
        result['full_execution'] &= ordered
        if not ordered and not any('ORDER' in reason or 'READ_COUNT' in reason
                                   for reason in result['design_diagnostics']):
            result['silent_obligations'] += 1
    if (gap := rubric['gap']) and gap['reason'] == 'UNAPPROVED_STATUS':
        exact = [entry for entry in summary.get('http_status_requirements', [])
                 if gap['source'] in entry['source_quote'] and entry['expected'] == gap['value']
                 and entry['status'] == 'NEEDS_REVIEW']
        scoped = any(gap['operation'] in entry.get('blocked_operations', []) for entry in exact)
        questions = [q for q in summary.get('questions', []) if q.get('operation_id')
                     == gap['operation']]
        status_rejection = 'DESIGN_REQUIRED_HTTP_STATUS_MISSING' in result['design_diagnostics']
        was_visible = bool(questions)
        is_visible = scoped or bool(exact and (questions or status_rejection))
        result['silent_obligations'] += int(was_visible) - int(is_visible)
        result['correct_hold'] = (is_visible and result['held_requested_scope']
            and all(result['verified_steps']) and result['scope_violations'] == 0)
    return result


if __name__ == '__main__':
    if len(sys.argv) > 1:
        root = Path(sys.argv[1]).resolve()
    freeze = read(root / 'freeze.json')
    terminal = read(root / 'schedule-terminal.json')
    digest = hashlib.sha256((root / 'freeze.json').read_bytes()).hexdigest()
    assert digest == (root / 'freeze.sha256').read_text().strip() == terminal['digest']
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == freeze['scorer_sha256']
    rows = {row['id']: row for row in terminal['records']}
    assert len(rows) == len(terminal['records']) == len(freeze['tasks']) * freeze['rounds'] * 2
    arms = {}
    for arm in ('baseline', 'candidate'):
        results = [score(rows[f"{task['id']}_r{turn}_{arm}"], task, freeze['configs'][task['config']])
                   for task in freeze['tasks'] for turn in range(1, freeze['rounds'] + 1)]
        auditable = [r for r in results if r['silent_obligations'] is not None]
        execution = sum(task['rubric']['gap'] is None for task in freeze['tasks']) * freeze['rounds']
        holds = len(results) - execution
        times = [r['elapsed_ms'] for r in results if 'elapsed_ms' in r]
        arms[arm] = dict(execution_denominator=execution, hold_denominator=holds,
            audited_obligations=sum(r['obligation_denominator'] for r in auditable),
            planned_obligations=sum(r['obligation_denominator'] for r in results),
            statuses=Counter(r['status'] for r in results),
            complete=sum(r['full_execution'] for r in results),
            false_refusals=sum(r.get('false_refusal', False) for r in results),
            correct_holds=sum(r['correct_hold'] for r in results),
            silent_obligations=sum(r['silent_obligations'] for r in auditable),
            unauthorized_attempts=sum(r['unauthorized_attempts'] for r in results),
            scope_violations=sum(r.get('scope_violations', 0) for r in results),
            target_requests=sum(r.get('requests', 0) for r in results),
            target_retries=sum(r['target_retries'] for r in results),
            infra_attempts=sum(r['infra_attempts'] for r in results),
            model_calls=sum(r.get('model_calls', 0) for r in results),
            known_tokens=sum(r.get('usage', {}).get('known_tokens', 0) for r in results),
            unknown_positions=sum(r.get('usage_known') is False and r.get('model_calls', 0) > 0
                                  for r in results),
            median_elapsed_ms=statistics.median(times) if times else None, positions=results)
    print(json.dumps(dict(freeze_sha256=digest, stop=terminal['stop'], arms=arms),
                     ensure_ascii=False, indent=2))
