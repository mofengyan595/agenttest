"""Read a successful schedule's omitted stop flag as null without changing its bytes."""

import runpy
from pathlib import Path

import audit_requirement_witness_comparison as audit

root = Path(__file__).resolve().parent
original_read = audit.read


def read(path):
    data = original_read(path)
    if path == root / 'schedule-terminal.json':
        data.setdefault('stop', None)
    return data


audit.read = read
runpy.run_path(str(root / 'score.py'), run_name='__main__')
